"""牛客 → ICPC CCS Event Feed 适配器

把牛客比赛数据转成 ICPC Tools 能直接消费的 Contest API，让大屏 75 个模块可用。

## 数据来源（已实测连通）

    GET https://ac.nowcoder.com/problem/tracker/acm/submission/list
        ?contestId=<CID>&problemId=0&userId=0
        &acceptedOnly=false&unsentOnly=false&page=1&limit=500

    需要登录 Cookie（放在环境变量 NOWCODER_COOKIE）。

    实测返回结构:
    {"code":0,"msg":"OK","data":{
      "total":2,
      "contest":{"contestId":144333,"name":"测试",
                 "startTime":1794925500000,"endTime":1795190340000},
      "problems":[{"virtualId":"A","problemId":328204,"title":"概率很小..."}],
      "submissions":[{
         "submissionId":85579538,
         "submitTime":1794926287000,          # 毫秒时间戳 ★用它
         "submitTimeText":"2026-11-17 22:38:07",
         "virtualId":"A","problemId":328204,"problemTitle":"...",
         "userName":"...","userId":403670559,"school":"",
         "accepted":true,"status":5,           # 5=AC
         "rightCaseRate":1.0,"balloonSent":false
      }]}}

## 对外提供（CCS Contest API）

    GET /api/contests/<id>                     比赛元信息
    GET /api/contests/<id>/teams               队伍
    GET /api/contests/<id>/problems            题目
    GET /api/contests/<id>/event-feed          NDJSON 事件流（增量）
    GET /api/status                            运行状态

## 用法

推荐用启动器（会读配置、开网页）：

    python launch.py

或者直接起（参数缺省全部读 overrides.json）：

    $env:NOWCODER_COOKIE = "<浏览器 Cookie>"
    python nowcoder_bridge.py --port 8080

配置页 http://127.0.0.1:8080/config ：比赛链接、轮询间隔、判题停留秒数、
Cookie、学校、题色、status 码映射都在这里改，保存立即生效。

ICPC Tools 连接:
    standalone http://127.0.0.1:8080/api/contests/144333 admin x -p 58 56

Cookie 优先从 cookie.txt 读，其次环境变量 NOWCODER_COOKIE。
"""

import argparse
import json
import os
import re
import sys
import threading
import time
import urllib.error
import urllib.parse
import urllib.request
from datetime import datetime, timedelta, timezone
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path

from overrides import (Overrides, contest_id_from, mask_cookie,
                       read_cookie_file, write_cookie_file)

TZ = timezone(timedelta(hours=8))

# 配置页面所在目录（web/config.html）。用 __file__ 定位，
# 这样从任何工作目录启动都能找到页面。
WEB_DIR = Path(__file__).resolve().parent / "web"
# 演示端要的图片素材（logo / banner / 组织 logo），按 CDP 的 present/ 目录结构放
PRESENT_DIR = WEB_DIR / "present"
OVERRIDES_PATH = Path(__file__).resolve().parent / "overrides.json"
# Scorewall 大屏前端源码目录（直接托管，保持单一来源，改完刷新即可）
SCOREWALL_DIR = Path(os.environ.get("SCOREWALL_DIR", r"D:\git\icpc-bigscreen\src"))
# ICPC 风格气球配色（用于给题目上色）。
# 牛客接口不返回颜色，只有 virtualId/problemId/title，必须自己生成，
# 否则 ICPC Tools 把 rgb 当 BLACK，题目格子全黑。
BALLOON_PALETTE = [
    "#FF7109",  # A orange
    "#008100",  # B forest green
    "#E93603",  # C red
    "#541298",  # D violet
    "#9B630C",  # E brown
    "#9486EA",  # F periwinkle
    "#81D8CF",  # G turquoise
    "#FFFF00",  # H yellow
    "#0F52BA",  # I sapphire
    "#FF2A85",  # J pink
    "#1E9E50",  # K green
    "#FBA3B8",  # L light pink
    "#ADD8E6",  # M light blue
    "#FFD700",  # N gold
]

API = "https://ac.nowcoder.com/problem/tracker/acm/submission/list"
# 比赛提交列表（页面 #submit 用的接口）。气球工作台 API 只给「谁第一次过某题」，
# 同队重复 AC 同一题不再发气球，那些提交就永远拿不到 —— 所以提交列表必须走这里。
STATUS_API = "https://ac.nowcoder.com/acm/contest/status-list"
# statusMessage 是中文结论文案，映射到 CCS judgement type。
# PENDING 表示还在评测：只发 submission，等下一轮出终态再补 judgement。
STATUS_CN = {
    "答案正确": "AC",
    "答案错误": "WA",
    "段错误": "RTE",
    "运行错误": "RTE",
    "系统错误": "RTE",
    "编译错误": "CE",
    "运行超时": "TLE",
    "内存超限": "MLE",
    "输出超限": "OLE",
    "格式错误": "PE",
    "评测中": "PENDING",
    "等待评测": "PENDING",
    "排队中": "PENDING",
}

# 牛客 status 数字码 -> CCS judgement type。
# 这几个是用提交详情页的"运行状态"文案逐个核对过的（不是猜）：
#   status=5  运行状态=答案正确  -> AC
#   status=4  运行状态=答案错误  -> WA
#   status=12 运行状态=编译错误  -> CE   （timeConsumption=0 也印证是编译期失败）
# 其余码没见过，先按牛客常见约定放这里；真正的兜底是启动时自动探测
# （见 Nowcoder.autodetect_verdicts）与配置页的手工覆盖。
STATUS_MAP = {
    # 已验证（提交详情页文案 + 构造用例实测）
    0: "PENDING",  # 评测中/排队中：还没有结论，不能当成错误
    4: "WA",
    5: "AC",
    6: "TLE",
    7: "MLE",
    12: "CE",
    15: "RTE",
    # 没见过，按牛客常见约定先放着；真出现时自动识别会覆盖
    8: "PE",
    13: "OLE",
}

# 这个不是 CCS judgement type，是适配器内部标记：
# 表示"牛客还没判完"，此时只发 submission 不发 judgement，
# 提交会留在判题队列里，等状态转成终态的那一轮再补 judgement。
PENDING = "PENDING"

# 牛客提交详情页上的中文判题结论 -> CCS judgement type
VERDICT_MAP = {
    "答案正确": "AC",
    "答案错误": "WA",
    "编译错误": "CE",
    "编译失败": "CE",
    "运行超时": "TLE",
    "时间超限": "TLE",
    "运行错误": "RTE",
    "段错误": "RTE",
    "浮点错误": "RTE",
    "内存超限": "MLE",
    "内存溢出": "MLE",
    "格式错误": "PE",
    "输出超限": "OLE",
    "系统错误": "RTE",
    "评测机错误": "RTE",
    "未知错误": "RTE",
}


def verdict_to_judge(text):
    """把详情页文案映射成 judgement type，允许文案里带别的话。"""
    if not text:
        return None
    t = text.strip()
    if t in VERDICT_MAP:
        return VERDICT_MAP[t]
    for key, jt in VERDICT_MAP.items():
        if key in t:
            return jt
    return None

JUDGE_TYPES = [
    {"id": "AC",  "name": "correct",               "penalty": False, "solved": True},
    {"id": "WA",  "name": "wrong answer",          "penalty": True,  "solved": False},
    {"id": "TLE", "name": "time limit exceeded",   "penalty": True,  "solved": False},
    {"id": "RTE", "name": "run time error",        "penalty": True,  "solved": False},
    {"id": "CE",  "name": "compilation error",     "penalty": False, "solved": False},
    {"id": "MLE", "name": "memory limit exceeded", "penalty": True,  "solved": False},
    {"id": "PE",  "name": "presentation error",    "penalty": True,  "solved": False},
    {"id": "OLE", "name": "output limit exceeded", "penalty": True,  "solved": False},
]


# ---------------- 牛客抓取 ----------------

class Nowcoder:
    def __init__(self, contest_id, cookie, ov=None):
        self.contest_id = str(contest_id)
        self.cookie = cookie
        self._cache = {}
        self._contest = None
        self._problems = {}
        self.ov = ov

    def _headers(self):
        return {
            "User-Agent": ("Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
                           "AppleWebKit/537.36 (KHTML, like Gecko) "
                           "Chrome/131.0.0.0 Safari/537.36"),
            "Accept": "application/json, text/plain, */*",
            "Referer": f"https://ac.nowcoder.com/acm/contest/{self.contest_id}",
            "X-Requested-With": "XMLHttpRequest",
            "Cookie": self.cookie,
        }

    def _get_json(self, url):
        req = urllib.request.Request(url, headers=self._headers())
        try:
            with urllib.request.urlopen(req, timeout=30) as r:
                data = json.loads(r.read().decode("utf-8"))
        except urllib.error.HTTPError as e:
            raise RuntimeError(f"HTTP {e.code}: {e.reason}")
        if int(data.get("code", -1)) != 0:
            raise RuntimeError(f"nowcoder code={data.get('code')} msg={data.get('msg')}")
        return data.get("data") or {}

    def _fetch(self, page=1, limit=50):
        """比赛提交列表（status-list）。返回结构保持和气球工作台一致，
        这样 _normalize / ingest 全都不需要改。"""
        q = urllib.parse.urlencode({
            "token": "",
            "id": self.contest_id,
            "page": page,
            "pageSize": limit,
            "contestTypeList": "contest",
            "_": int(time.time() * 1000),
        })
        data = self._get_json(STATUS_API + "?" + q)
        basic = data.get("basicInfo") or {}
        rows = data.get("data") or []
        if isinstance(rows, dict):
            rows = rows.get("list") or rows.get("data") or []

        subs = []
        for r in rows:
            msg = (r.get("statusMessage") or "").strip()
            jt = STATUS_CN.get(msg)
            if jt is None:
                # 没见过的文案：先当 WA 但记下来，配置页能看到原始文案
                jt = "WA"
            subs.append({
                "submissionId": r.get("submissionId"),
                "submitTime": r.get("submitTime"),
                "virtualId": r.get("index"),
                "problemId": r.get("problemId"),
                "userId": r.get("userId"),
                "userName": r.get("userName"),
                "school": "",
                "problemTitle": "",
                # 直接把中文结论塞进 status，_normalize 会原样透传成 judge_type
                "status": jt,
                "accepted": jt == "AC",
                "statusMessage": msg,
                "rightCaseRate": 1.0 if jt == "AC" else 0.0,
            })
        return {
            "total": int(basic.get("statusCount") or len(subs)),
            "submissions": subs,
            "contest": self._contest,
            "problems": list(self._problems.values()),
        }

    def _fetch_meta(self):
        """气球工作台接口，只用来拿 contest（开始/结束时间）和题目列表。
        status-list 不返回这两块。"""
        q = urllib.parse.urlencode({
            "contestId": self.contest_id, "problemId": 0, "userId": 0,
            "acceptedOnly": "false", "unsentOnly": "false", "page": 1, "limit": 1,
        })
        return self._get_json(API + "?" + q)

    def poll(self):
        """拉全量，返回 (problems_raw, new_records)。"""
        # contest（开始/结束时间）和题目列表只有气球工作台接口有，先取一次
        try:
            meta = self._fetch_meta()
            if meta:
                self._contest = meta.get("contest") or self._contest
                for p in meta.get("problems") or []:
                    self._problems[str(p.get("virtualId"))] = p
        except Exception as e:
            print(f"  [WARN] 拉比赛元信息失败: {e}", flush=True)

        first = self._fetch(page=1, limit=50)
        total = int(first.get("total") or 0)
        self._contest = first.get("contest") or self._contest
        probs = first.get("problems") or []
        for p in probs:
            self._problems[str(p.get("virtualId"))] = p
        rows = list(first.get("submissions") or [])

        page = 2
        while len(rows) < total and page <= 100:
            chunk = self._fetch(page=page)
            more = chunk.get("submissions") or []
            if not more:
                break
            rows.extend(more)
            for p in chunk.get("problems") or []:
                self._problems[str(p.get("virtualId"))] = p
            page += 1

        return probs, self._normalize(rows)

    @staticmethod
    def _ts(row):
        """优先用毫秒时间戳 submitTime，回退解析 submitTimeText。"""
        v = row.get("submitTime")
        if isinstance(v, (int, float)) and v > 0:
            return datetime.fromtimestamp(v / 1000, TZ)
        txt = row.get("submitTimeText") or ""
        for fmt in ("%Y-%m-%d %H:%M:%S", "%Y-%m-%d %H:%M"):
            try:
                return datetime.strptime(txt, fmt).replace(tzinfo=TZ)
            except ValueError:
                continue
        return datetime.now(TZ)

    def _normalize(self, rows):
        new = []
        for r in rows:
            sid = str(r.get("submissionId"))
            if not sid:
                continue
            status = r.get("status")
            accepted = bool(r.get("accepted"))
            # status-list 已经把中文结论翻成 judgement type（AC/WA/RTE/.../PENDING）
            if isinstance(status, str) and status.isupper() and not status.isdigit():
                jt = status
            elif accepted:
                jt = "AC"
            elif self.ov is not None:
                jt = self.ov.status_to_judge(status, accepted)
            else:
                jt = STATUS_MAP.get(status, "WA")
            old = self._cache.get(sid)
            if old is not None and old.get("status") == status \
                    and bool(old.get("accepted")) == accepted:
                continue        # 没变化
            # 牛客 status 码含义未公开：用详情页文案核对过的几个见 STATUS_MAP，
            # 其余交给配置页映射。0 表示"还在评测"，要留在判题队列里等终态。
            rec = {
                "submission_id": sid,
                "time": self._ts(r),
                "team": str(r.get("userId") or ""),
                "team_name": r.get("userName") or f"user{r.get('userId')}",
                "school": r.get("school") or "",
                "problem_label": str(r.get("virtualId") or "").strip(),
                "problem_title": r.get("problemTitle") or "",
                "judge_type": jt,
                "accepted": accepted,
                # 原始 status 码留着，配置页要靠它统计"每个码出现了多少次"
                "status": status,
            }
            if not rec["problem_label"]:
                continue        # 无法归属题目的记录跳过，避免污染榜单
            self._cache[sid] = rec
            # 老记录状态变了（评测中 -> 终态）也要重新下发，否则永远停在 pending
            new.append(rec)
        new.sort(key=lambda x: x["time"])
        return new

    @property
    def contest(self):
        return self._contest or {}

    @property
    def problems(self):
        return list(self._problems.values())

    # ---- 判题结论核对（把"猜 status 码"变成"读文案"）----

    def verdict(self, submission_id, timeout=20):
        """抓提交详情页，返回中文判题结论（如"答案错误"）。失败返回 None。"""
        url = ("https://ac.nowcoder.com/acm/contest/view-submission"
               f"?submissionId={submission_id}")
        req = urllib.request.Request(url, headers={
            "User-Agent": ("Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
                           "AppleWebKit/537.36 (KHTML, like Gecko) "
                           "Chrome/131.0.0.0 Safari/537.36"),
            "Referer": f"https://ac.nowcoder.com/acm/contest/{self.contest_id}",
            "Cookie": self.cookie,
        })
        try:
            with urllib.request.urlopen(req, timeout=timeout) as r:
                html = r.read().decode("utf-8", "replace")
        except Exception:
            return None
        m = re.search(r"运行状态[：:]\s*<span[^>]*>\s*([^<]+?)\s*</span>", html)
        return m.group(1).strip() if m else None

    def autodetect_verdicts(self, records, max_codes=6, per_code=2):
        """对没见过的 status 码，抽一条提交去详情页读真实结论，写进配置。

        这比枚举数字码可靠：牛客详情页有"答案正确/答案错误/编译错误/运行超时..."
        的中文结论，直接映射成 CCS judgement type。
        返回 {status_code: judge_type}。
        """
        known = (self.ov.data.get("status_map") if self.ov else None) or {}
        bucket = {}
        for r in records:
            if r.get("accepted"):
                continue
            code = str(r.get("status"))
            if code in known or code in bucket:
                continue
            bucket[code] = r["submission_id"]

        learned = {}
        for code, _ in list(bucket.items())[:max_codes]:
            sids = [r["submission_id"] for r in records
                    if str(r.get("status")) == code and not r.get("accepted")][:per_code]
            for sid in sids:
                v = self.verdict(sid)
                if not v:
                    continue
                jt = verdict_to_judge(v)
                if jt:
                    learned[code] = jt
                    if self.ov:
                        self.ov.learn_status(code, jt)
                    break
        return learned

    def remap(self, records):
        """配置/自动识别改了映射后，重算已归一化记录的 judge_type。"""
        for r in records:
            if r.get("accepted"):
                r["judge_type"] = "AC"
            elif self.ov is not None:
                r["judge_type"] = self.ov.status_to_judge(r.get("status"), False)
            else:
                r["judge_type"] = STATUS_MAP.get(r.get("status"), "WA")
            self._cache[r["submission_id"]] = r
        return records


# ---------------- CCS 模型 ----------------

class ContestState:
    # 时长直接用牛客的 startTime → endTime（自动识别），不再按"单场比赛 6 小时"
    # 去截断 —— 那种热身赛/练习赛本来就开放好几天，截断会把正常提交误判成赛外，
    # 榜单罚时和判题队列都会错。
    # 这里只留一个防明显异常值的天花板（牛客偶尔返回 1970 或空值）。
    MAX_DURATION_MIN = 60 * 24 * 30     # 30 天

    def __init__(self, contest_id, name, start, end, penalty_sec, ov=None):
        self.id = str(contest_id)
        self.start = start
        self.end = end
        self.ov = ov
        self._base_name = name
        self._base_penalty = penalty_sec
        self._real_min = int((end - start).total_seconds() // 60)
        self.duration_min_override = None
        self.freeze_sec = 0
        self.refresh()

    def refresh(self):
        """把配置页的比赛级设置套上来。可反复调用（配置保存后立即生效）。"""
        cfg = self.ov.contest() if self.ov else {}
        self.name = cfg.get("name") or self._base_name
        try:
            self.penalty_sec = int(cfg.get("penalty_sec") or self._base_penalty)
        except (TypeError, ValueError):
            self.penalty_sec = self._base_penalty
        cfg_dur = cfg.get("duration_min")
        if cfg_dur:
            try:
                self.duration_min_override = max(1, int(cfg_dur))
            except (TypeError, ValueError):
                self.duration_min_override = None
        if self.duration_min_override is None:
            if self._real_min > self.MAX_DURATION_MIN or self._real_min <= 0:
                self.duration_min_override = self.MAX_DURATION_MIN
        try:
            self.freeze_sec = max(0, int(cfg.get("freeze_min") or 0)) * 60
        except (TypeError, ValueError):
            self.freeze_sec = 0
        return self

    def signature(self):
        """用于判断比赛元信息是否变化（变了才补发 contests 事件）。"""
        m = self.meta()
        return (m["name"], m["duration"], m["penalty_time"],
                m["scoreboard_freeze_duration"])

    def file_refs(self):
        """contest 对象上的 logo / banner 图片引用。

        ICPC Tools 的 Info.getLogoImage()/getBannerImage() 就是读这两个字段
        （StaticLogoPresentation / MessagePresentation 都用它）。
        不发这两个字段的话，37/38/39 只会画一句"请把图片放到 CDS"的提示。
        href 用 / 开头，RESTContestSource 会按 `协议://主机 + href` 解析。
        """
        # 文件名带版本号：ICPC Tools 会按文件名缓存下载过的图，同名换图不生效
        refs = {}
        for name, w, h in (("logoA2.png", 2048, 2048), ("logoA.png", 1024, 1024)):
            if (PRESENT_DIR / name).is_file():
                refs["logo"] = [{"href": f"/presentation/{name}",
                                 "width": w, "height": h}]
                break
        if (PRESENT_DIR / "banner2.png").is_file():
            refs["banner"] = [{"href": "/presentation/banner2.png",
                               "width": 1920, "height": 640}]
        elif (PRESENT_DIR / "banner.png").is_file():
            refs["banner"] = [{"href": "/presentation/banner.png",
                               "width": 1920, "height": 640}]
        return refs

    def load_contest(self, contest, contest_id=None):
        """切换比赛后，用牛客返回的 contest 重算开始/结束时间与名字。"""
        if contest_id:
            self.id = str(contest_id)
        c = contest or {}
        st, en = c.get("startTime"), c.get("endTime")
        if st:
            self.start = datetime.fromtimestamp(st / 1000, TZ)
        if en:
            self.end = datetime.fromtimestamp(en / 1000, TZ)
        self._base_name = c.get("name") or f"牛客 {self.id}"
        self._real_min = int((self.end - self.start).total_seconds() // 60)
        self.duration_min_override = None
        return self.refresh()

    @property
    def duration_min(self):
        if self.duration_min_override is not None:
            return self.duration_min_override
        return max(1, int((self.end - self.start).total_seconds() // 60))

    def contest_time(self, dt):
        """绝对时间 -> CCS 相对时间。

        格式必须严格匹配 RelativeTime 的正则：
            -?([0-9]+):([0-9]{2}):([0-9]{2})(\\.[0-9]{3})?
        即毫秒部分**恰好 3 位**。写成 6 位（.000000）会导致
            java.text.ParseException: Invalid contest time string
        整个事件被丢弃，榜上就没有任何状态。
        """
        sec = max(0.0, (dt - self.start).total_seconds())
        total_ms = int(round(sec * 1000))
        h = total_ms // 3600000
        rem = total_ms % 3600000
        m = rem // 60000
        rem %= 60000
        s = rem // 1000
        ms = rem % 1000
        return f"{h}:{m:02d}:{s:02d}.{ms:03d}"

    @staticmethod
    def _hms(total_sec):
        h = int(total_sec // 3600)
        m = int((total_sec % 3600) // 60)
        s = int(total_sec % 60)
        return f"{h}:{m:02d}:{s:02d}"

    def start_time(self):
        """开赛时刻。配置里填了 contest.start_at 就以它为准（赛前排练用）。"""
        cfg = self.ov.contest() if self.ov else {}
        raw = (cfg.get("start_at") or "").strip()
        if not raw:
            return self.start
        try:
            if raw.startswith("now"):
                # now / now+30m / now-5m
                mins = 0
                rest = raw[3:].strip()
                if rest[:1] in ("+", "-"):
                    val = rest[1:].strip().lower()
                    if val.endswith("m"):
                        mins = int(val[:-1])
                    elif val.endswith("h"):
                        mins = int(val[:-1]) * 60
                    else:
                        mins = int(val)
                    if rest[0] == "-":
                        mins = -mins
                return datetime.now(TZ) + timedelta(minutes=mins)
            txt = raw.replace("T", " ").replace("Z", "").strip()
            for fmt in ("%Y-%m-%d %H:%M:%S", "%Y-%m-%d %H:%M", "%Y-%m-%d"):
                try:
                    return datetime.strptime(txt[:len(txt)], fmt).replace(tzinfo=TZ)
                except ValueError:
                    continue
        except (ValueError, TypeError):
            pass
        return self.start

    def meta(self):
        st = self.start_time()
        m = {
            "id": self.id,
            "name": self.name,
            "formal_name": self.name,
            "start_time": st.astimezone(timezone.utc)
                             .strftime("%Y-%m-%dT%H:%M:%S.000Z"),
            "duration": self._hms(self.duration_min * 60),
            # 封榜时长。ICPC Tools 的 Scoreboard 会据此在封榜时刻冻结公开榜。
            # 配置页 freeze_min=0 表示全程公开（不封榜）。
            "scoreboard_freeze_duration": self._hms(self.freeze_sec),
            # CCS 规范里 penalty_time 单位是**分钟**（ICPC Tools 的 Info.addImpl
            # 是 parseInt(value) * 60000）。这里内部存秒，发之前换算。
            "penalty_time": max(0, int(self.penalty_sec) // 60),
        }
        m.update(self.file_refs())
        return m


class FeedStore:
    def __init__(self, state, nowcoder, fake_pending=0, judge_delay=0.0, ov=None):
        self.s = state
        self.nc = nowcoder
        self._events = []
        self._subs = set()
        self._judges = set()
        self._teams = {}
        self._problems = {}
        self._emitted_meta = False
        self.ov = ov
        # 这两个只当"配置里没写时的兜底"：
        # judge_delay = 提交在判题队列里停留多少秒才落到榜单；
        # fake_pending = 最早的 N 条提交永久留 pending（演示/开场用）。
        # 真正的取值每轮从 ov.runtime() 读，配置页改完立刻生效。
        self._fallback_judge_delay = max(0.0, float(judge_delay))
        self._fallback_fake_pending = max(0, int(fake_pending))
        self._fake_consumed = 0
        self._pending_judge = {}     # sid -> (due_time, payload)
        # 累计缓存：轮询是增量的，最后一次拉取可能只有几条甚至 0 条，
        # 而配置页需要"现在全部队伍/全部提交"的视图，所以按 id 累积而不是覆盖。
        self._records = {}           # submission_id -> rec
        self._last_problems_raw = []
        self._meta_sig = None
        self._judge_emitted = {}     # jid -> 已发出的 judgement_type_id
        self._entity_sig = {}        # (kind, id) -> 已发出的实体指纹
        self._probed_codes = set()   # 已经去详情页核对过的 status 码
        self.lock = threading.Lock()

    @property
    def judge_delay(self):
        if self.ov is not None:
            return self.ov.runtime()["judge_delay"]
        return self._fallback_judge_delay

    @property
    def fake_pending(self):
        if self.ov is not None:
            return self.ov.runtime()["fake_pending"]
        return self._fallback_fake_pending

    def _entities(self, records, problems_raw):
        ov = self.ov
        # 整场比赛都算某个学校：填一次"默认学校"，没单独填的队伍全用它，
        # 新出现的队伍也自动带上，不用一队一队补。
        defaults = ov.team_defaults() if ov else {"school": "", "star": False}
        for p in problems_raw:
            label = str(p.get("virtualId") or "").strip()
            if not label:
                continue
            ordinal = ord(label[0].upper()) - 65 if label[0].isalpha() else len(self._problems)
            # 配置页可覆盖题目名与颜色
            cfg_p = ov.problem(label) if ov else {}
            name = cfg_p.get("title") or p.get("title") or label
            # 牛客接口不返回题目颜色，只有 virtualId/problemId/title。
            # Problem.java 支持 rgb 字段（#RRGGBB），缺这个字段时按 BLACK 处理，
            # 题目格子就成了黑色。默认按 ICPC 气球配色分配，配置页可覆盖。
            rgb = cfg_p.get("rgb") or BALLOON_PALETTE[ordinal % len(BALLOON_PALETTE)]
            if label in self._problems:
                # 配置改过：原地刷新可变字段（刷新事件靠 refresh_entities 补发）
                self._problems[label]["name"] = name
                self._problems[label]["rgb"] = rgb
                continue
            self._problems[label] = {
                "id": label,
                "label": label,
                "name": name,
                "ordinal": ordinal,
                "test_data_count": 1,
                "rgb": rgb,
            }
        for r in records:
            tid = r["team"]
            if not tid:
                continue
            cfg_t = ov.team(tid) if ov else {}
            # 牛客 school 字段实测全为空串，学校只能从配置页来：
            # 队伍单独填 > 牛客返回值 > 全场默认学校
            school = (cfg_t.get("school") or r["school"]
                      or defaults.get("school") or "")
            star = bool(cfg_t.get("star", defaults.get("star", False)))
            if tid in self._teams:
                # 配置可能刚改过，刷新可变字段
                t = self._teams[tid]
                t["organization_id"] = school or None
                t["group_ids"] = ["unofficial"] if star else ["participants"]
                continue
            self._teams[tid] = {
                "id": tid,
                "name": cfg_t.get("name") or r["team_name"],
                "display_name": cfg_t.get("name") or r["team_name"],
                "group_ids": ["unofficial"] if star else ["participants"],
                "organization_id": school or None,
            }

    def _meta_events(self):
        """CCS event-feed 是全量事件流。

        格式必须照 NDJSONFeedParser 的要求：每个事件是
            {"type": "<type>", "id": "<id>", "data": { <对象字段> }}
        data 是必需的外层包裹。如果缺少 data，解析器取到 null 后
        会当成 "删除该对象"（contest.add(new Deletion(id, cType))），
        于是所有事件都被当作删除，模型里题目/队伍数始终为 0，
        画面只剩标题栏。
        """
        ev = []
        m = self.s.meta()

        def wrap(ctype, oid, body):
            return {"type": ctype, "id": oid, "data": body}

        ev.append(wrap("contests", m["id"], {
            "id": m["id"], "name": m["name"], "formal_name": m["formal_name"],
            "start_time": m["start_time"], "duration": m["duration"],
            "scoreboard_freeze_duration": m["scoreboard_freeze_duration"],
            "penalty_time": m["penalty_time"],
            **self.s.file_refs(),
        }))
        ev.append(wrap("groups", "participants",
                       {"id": "participants", "name": "participants"}))
        ev.append(wrap("languages", "unknown",
                       {"id": "unknown", "name": "Unknown", "extensions": []}))
        for jt in JUDGE_TYPES:
            body = dict(jt)
            body["id"] = jt["id"]
            ev.append(wrap("judgement-types", jt["id"], body))
        # 组织必须在 teams 之前发：teams 里 organization_id 指向它，
        # 没有对应 organizations 对象时榜单的队伍行就显示不出学校。
        for o in self._organizations():
            ev.append(wrap("organizations", o, self._org_body(o)))
        # 现场工位（SitesStatusCountdownPresentation 读 organizations + start-status）
        for st in (self.ov.sites() if self.ov else []):
            ev.append(wrap("organizations", st["id"],
                           {"id": st["id"], "name": st["name"],
                            "formal_name": st["name"]}))
            ev.append(wrap("start-status", st["id"],
                           {"id": st["id"], "label": st["name"],
                            "status": st["status"]}))
        for p in sorted(self._problems.values(), key=lambda x: x.get("ordinal", 0)):
            ev.append(wrap("problems", p["id"], {
                "id": p["id"], "label": p["label"], "name": p["name"],
                "ordinal": p["ordinal"], "test_data_count": 1, "rgb": p["rgb"],
            }))
        for t in self._teams.values():
            body = {
                "id": t["id"], "name": t["name"],
                "display_name": t["display_name"], "group_ids": t["group_ids"],
            }
            if t.get("organization_id"):
                body["organization_id"] = t["organization_id"]
            ev.append(wrap("teams", t["id"], body))
        return ev

    def ingest(self, records, problems_raw):
        with self.lock:
            teams_before = set(self._teams)
            probs_before = set(self._problems)
            self._last_problems_raw = problems_raw
            for r in records:
                self._records[r["submission_id"]] = r
            self._entities(list(self._records.values()), problems_raw)

            added = 0
            # 首次：把全部元信息事件放到流最前面
            if not self._emitted_meta and (self._problems or self._teams):
                meta = self._meta_events()
                self._events = meta + self._events
                self._emitted_meta = True
                self._meta_sig = self.s.signature() if hasattr(self.s, "signature") else None
                added += len(meta)
            else:
                # 后续增量：新出现的队伍/题目必须补发 teams/problems 事件，
                # 否则 ICPC Tools 的模型里没有这个实体，
                # 引用它的 submission 会被丢弃（队伍数不变、格子上不出现状态）。
                for tid, t in self._teams.items():
                    if tid in teams_before:
                        continue
                    body = {
                        "id": t["id"], "name": t["name"],
                        "display_name": t["display_name"],
                        "group_ids": t["group_ids"],
                    }
                    if t.get("organization_id"):
                        body["organization_id"] = t["organization_id"]
                    self._events.append({"type": "teams", "id": tid, "data": body})
                    added += 1
                for label, p in self._problems.items():
                    if label in probs_before:
                        continue
                    self._events.append({
                        "type": "problems", "id": label,
                        "data": {
                            "id": p["id"], "label": p["label"], "name": p["name"],
                            "ordinal": p["ordinal"], "test_data_count": 1, "rgb": p["rgb"],
                        },
                    })
                    added += 1

            for r in records:
                sid = str(r["submission_id"])
                ct = self.s.contest_time(r["time"])
                iso = r["time"].astimezone(timezone.utc).strftime("%Y-%m-%dT%H:%M:%S.000Z")
                if sid not in self._subs:
                    self._events.append({
                        "type": "submissions",
                        "id": sid,
                        "data": {
                            "id": sid,
                            "contest_time": ct,
                            "team_id": r["team"],
                            "problem_id": r["problem_label"],
                            "language_id": "unknown",
                        },
                    })
                    self._subs.add(sid)
                    added += 1
                jid = "j" + sid
                if jid not in self._judges:
                    if r["judge_type"] == PENDING:
                        # 牛客还在评测：只下发 submission，让它留在判题队列里。
                        # 下一轮它的 status 变了，_normalize 会重新给出来，
                        # 那时才补 judgement —— 否则会立刻记一次错罚时。
                        continue
                    # JudgePresentation 只把 !isJudged(submission) 的提交放进队列
                    # （见 JudgePresentation.java）。因此延迟发出 judgement 就能让
                    # 提交先在队列里显示为 pending，到点后再落到榜单——
                    # 这比永久挂起更接近真实比赛：牛客本身也要几秒才判完。
                    if self._fake_consumed < self.fake_pending:
                        # 开场铺垫：最早的 N 条永久保持 pending
                        self._fake_consumed += 1
                        self._judges.add(jid)
                        continue

                    # Judgement 的字段要求和 Submission 不同（见 Judgement.java）：
                    #   只认 start_time / end_time（绝对时间）与
                    #        start_contest_time / end_contest_time（相对时间），
                    #   没有 contest_time 字段（会报 "Unknown property ignored"）。
                    # 且 validate() 明确要求 end_time 与 end_contest_time 都存在，
                    # 否则判定为 "Missing end time" / "Missing end contest time"，
                    # 该 judgement 不生效 —— 榜上就只剩题目格子而没有状态。
                    payload = {
                        "type": "judgements",
                        "id": jid,
                        "data": {
                            "id": jid,
                            "submission_id": sid,
                            "judgement_type_id": r["judge_type"],
                            "start_time": iso,
                            "end_time": iso,
                            "start_contest_time": ct,
                            "end_contest_time": ct,
                        },
                    }
                    if self.judge_delay > 0:
                        # 排队，等 tick() 到点后再真正写进事件流
                        self._pending_judge[sid] = (time.time() + self.judge_delay, payload)
                        self._judges.add(jid)
                    else:
                        self._events.append(payload)
                        self._judges.add(jid)
                        self._judge_emitted[jid] = r["judge_type"]
                        added += 1
            # 牛客已经不存在的提交要发删除事件（data=null）。
            # _subs 只增不减的话，提交失败/被平台丢弃的那些会永远留在队列里
            # 显示成 pending —— 牛客不给它们 judgement，前端就一直等。
            # 只清理「本轮没返回且没有 judgement」的，避免分页抖动误删正常提交。
            if records:
                alive = {str(r["submission_id"]) for r in records}
                for sid in [x for x in self._subs if x not in alive]:
                    if ("j" + sid) in self._judges:
                        continue                      # 已判的保留
                    self._events.append({"type": "submissions", "id": sid, "data": None})
                    self._subs.discard(sid)
                    added += 1
                    print(f"  [DROP] 牛客已不存在且未判，删除 {sid}", flush=True)

            if self._emitted_meta:
                self._remember_signatures()
            return added

    def tick(self):
        """把到期的延迟 judgement 写进事件流。返回新增事件数。

        发出前要用**当前**映射重算一次 judgement 类型：payload 是入队那一刻
        用旧映射拼的，而"status 码自动识别"往往就发生在延迟窗口内
        （先看到新提交、再读到结论）。不改的话会把 TLE/MLE 发成 WA。
        """
        if not self._pending_judge:
            return 0
        now = time.time()
        added = 0
        with self.lock:
            for sid in list(self._pending_judge):
                due, payload = self._pending_judge[sid]
                if now >= due:
                    rec = self._records.get(sid)   # sid 就是牛客的 submissionId
                    if rec is not None:
                        jt = self._judge_type_of(rec)
                        rec["judge_type"] = jt
                        if jt == PENDING:
                            # 还在评测：这一发先不发，2 秒后再看
                            self._pending_judge[sid] = (now + 2.0, payload)
                            continue
                        payload["data"]["judgement_type_id"] = jt
                    self._events.append(payload)
                    self._judge_emitted[payload["id"]] = \
                        payload["data"]["judgement_type_id"]
                    del self._pending_judge[sid]
                    added += 1
        return added

    def pending_count(self):
        with self.lock:
            return len(self._pending_judge)

    def lines(self, since=0):
        with self.lock:
            return [json.dumps(e, ensure_ascii=False) for e in self._events[since:]]

    def counts(self):
        with self.lock:
            return len(self._events), len(self._teams), len(self._problems)

    def snapshot(self, kind):
        with self.lock:
            if kind == "teams":
                return list(self._teams.values())
            if kind == "problems":
                return list(self._problems.values())
            orgs = {}
            for t in self._teams.values():
                o = t.get("organization_id")
                if o and o not in orgs:
                    orgs[o] = self._org_body(o)
            return list(orgs.values())

    # ---- 配置页支持 ----

    def _organizations(self):
        """队伍里出现过的所有学校名（去重、保序）。"""
        out = []
        for t in self._teams.values():
            o = t.get("organization_id")
            if o and o not in out:
                out.append(o)
        return out

    @staticmethod
    def _org_body(name):
        """organizations 事件体。带 logo 时 Logo Wall / Fading Logos 才有东西画。

        文件名故意带内容标识（dnui.png）：ICPC Tools 会缓存下载过的图片，
        同名换图不生效，换个名字才会重新拉。
        """
        body = {"id": name, "name": name, "formal_name": name}
        for f in ("org/dnui.png", "org/default.png"):
            if (PRESENT_DIR / f).is_file():
                body["logo"] = [{"href": f"present/{f}"}]
                break
        return body

    @staticmethod
    def _team_sig(t):
        return (t["name"], t["display_name"], tuple(t["group_ids"]),
                t.get("organization_id") or "")

    @staticmethod
    def _problem_sig(p):
        return (p["name"], p["rgb"], p["ordinal"])

    def _remember_signatures(self):
        """记下当前已发出的实体指纹，用来判断刷新时到底哪些变了。"""
        sig = {}
        for tid, t in self._teams.items():
            sig[("team", tid)] = self._team_sig(t)
        for lb, p in self._problems.items():
            sig[("problem", lb)] = self._problem_sig(p)
        for o in self._organizations():
            sig[("org", o)] = True
        for st in (self.ov.sites() if self.ov else []):
            sig[("site", st["id"])] = st["status"]
        self._entity_sig = sig

    def refresh_entities(self):
        """配置保存后重算实体，只把**真正变了**的东西补发成 events。

        ICPC Tools 的模型是"事件驱动 + addOrUpdate"：同一个 id 再发一次
        teams/problems 事件就会用新数据覆盖旧对象，所以队伍改学校、题目改颜色
        都能在不重启适配器、不重连客户端的情况下生效。
        没变的实体不发，避免每保存一次就把事件流灌胖一轮。
        返回补发的事件数。
        """
        with self.lock:
            if not self._emitted_meta:
                return 0
            self._entities(list(self._records.values()), self._last_problems_raw)
            added = 0
            sigs = dict(getattr(self, "_entity_sig", {}) or {})

            # 比赛元信息变了才补发（name/duration/penalty/freeze）
            sig = self.s.signature() if hasattr(self.s, "signature") else None
            if sig is not None and sig != self._meta_sig:
                m = self.s.meta()
                self._events.append({"type": "contests", "id": m["id"], "data": {
                    "id": m["id"], "name": m["name"],
                    "formal_name": m["formal_name"],
                    "start_time": m["start_time"], "duration": m["duration"],
                    "scoreboard_freeze_duration": m["scoreboard_freeze_duration"],
                    "penalty_time": m["penalty_time"],
                    **self.s.file_refs(),
                }})
                self._meta_sig = sig
                added += 1

            for o in self._organizations():
                if sigs.get(("org", o)):
                    continue
                self._events.append({"type": "organizations", "id": o,
                                     "data": self._org_body(o)})
                added += 1
            for st in (self.ov.sites() if self.ov else []):
                if sigs.get(("site", st["id"])) == st["status"]:
                    continue
                self._events.append({"type": "start-status", "id": st["id"],
                                     "data": {"id": st["id"],
                                              "label": st["name"],
                                              "status": st["status"]}})
                added += 1
            for label, p in self._problems.items():
                s = self._problem_sig(p)
                if sigs.get(("problem", label)) == s:
                    continue
                self._events.append({"type": "problems", "id": label, "data": {
                    "id": p["id"], "label": p["label"], "name": p["name"],
                    "ordinal": p["ordinal"], "test_data_count": 1, "rgb": p["rgb"],
                }})
                added += 1
            for tid, t in self._teams.items():
                s = self._team_sig(t)
                if sigs.get(("team", tid)) == s:
                    continue
                body = {"id": t["id"], "name": t["name"],
                        "display_name": t["display_name"],
                        "group_ids": t["group_ids"]}
                if t.get("organization_id"):
                    body["organization_id"] = t["organization_id"]
                self._events.append({"type": "teams", "id": tid, "data": body})
                added += 1

            # 状态映射改了：已经发过的 judgement 用同 id 再发一次即可覆盖，
            # 这样改配置能回填历史提交，而不是只影响以后的新提交。
            for rec in self._records.values():
                jt = self._judge_type_of(rec)
                rec["judge_type"] = jt
                if jt == PENDING:
                    continue        # 还在评测，不发 judgement
                jid = "j" + str(rec["submission_id"])
                old = self._judge_emitted.get(jid)
                if old is None or old == jt:
                    continue
                ct = self.s.contest_time(rec["time"])
                iso = rec["time"].astimezone(timezone.utc) \
                             .strftime("%Y-%m-%dT%H:%M:%S.000Z")
                self._events.append({"type": "judgements", "id": jid, "data": {
                    "id": jid, "submission_id": str(rec["submission_id"]),
                    "judgement_type_id": jt,
                    "start_time": iso, "end_time": iso,
                    "start_contest_time": ct, "end_contest_time": ct,
                }})
                self._judge_emitted[jid] = jt
                added += 1
            self._remember_signatures()
            return added

    def _judge_type_of(self, rec):
        if rec.get("accepted"):
            return "AC"
        if self.ov is not None:
            return self.ov.status_to_judge(rec.get("status"), False)
        return STATUS_MAP.get(rec.get("status"), "WA")

    def autodetect_status(self, force=False):
        """让 Nowcoder 去详情页读真实判题结论，写进配置后回填事件流。

        每轮都会调；force=False 时同一个没见过的码只试一次，
        免得反复打详情页（检测失败也记下来，不再重试）。
        """
        known = (self.ov.data.get("status_map") if self.ov else {}) or {}
        cand = [r for r in self._records.values()
                if str(r.get("status")) not in known
                and (force or str(r.get("status")) not in self._probed_codes)]
        if not cand:
            return {}
        for r in cand:
            self._probed_codes.add(str(r.get("status")))
        learned = self.nc.autodetect_verdicts(cand)
        if learned:
            self.refresh_entities()
        return learned

    def switch_contest(self, new_id):
        """换比赛：清空模型与事件流，按新比赛重新拉一遍。

        注意：已经连着的大屏会看到一次"比赛被替换"，建议重连客户端。
        返回 (题目数, 提交数)。
        """
        new_id = str(new_id)
        with self.lock:
            self.nc.contest_id = new_id
            self.nc._cache.clear()
            self.nc._contest = None
            self.nc._problems.clear()
            self._events.clear()
            self._subs.clear()
            self._judges.clear()
            self._teams.clear()
            self._problems.clear()
            self._records.clear()
            self._judge_emitted.clear()
            self._pending_judge.clear()
            self._last_problems_raw = []
            self._emitted_meta = False
            self._meta_sig = None
            self._fake_consumed = 0
            self.s.id = new_id
        probs, recs = self.nc.poll()
        self.s.load_contest(self.nc.contest, new_id)
        self.ingest(recs, probs)
        return len(probs), len(recs)

    def config_live_snapshot(self):
        """给配置页用的实时快照：现在到底有哪些队伍/题目/status 码。"""
        with self.lock:
            recs = list(self._records.values())
            status_counts = {}
            for r in recs:
                k = str(r.get("status"))
                status_counts[k] = status_counts.get(k, 0) + 1
            per_team = {}
            for r in recs:
                per_team[r["team"]] = per_team.get(r["team"], 0) + 1
            teams = [{
                "id": t["id"],
                "name": t["name"],
                "school": t.get("organization_id") or "",
                "star": "unofficial" in (t.get("group_ids") or []),
                "subs": per_team.get(t["id"], 0),
            } for t in self._teams.values()]
            teams.sort(key=lambda x: (-x["subs"], x["id"]))
            probs = [{
                "label": p["label"],
                "name": p["name"],
                "ordinal": p["ordinal"],
                "rgb": p["rgb"],
            } for p in sorted(self._problems.values(), key=lambda x: x["ordinal"])]
            return {
                "contest": self.s.meta(),
                "teams": teams,
                "problems": probs,
                "statusCounts": status_counts,
                "events": len(self._events),
                "pending": len(self._pending_judge),
            }


# ---------------- HTTP ----------------

class Handler(BaseHTTPRequestHandler):
    store = None
    state = None
    ov = None

    # 必须显式声明 HTTP/1.1：默认是 HTTP/1.0，响应结束即断连，
    # 流式 event-feed 会被客户端当成"连接中断"，ICPC Tools 于是反复
    # "Waiting to reconnect" 且榜单永远为空。
    protocol_version = "HTTP/1.1"

    def log_message(self, fmt, *a):
        print(f'[REQ] {self.address_string()} {fmt % a}', flush=True)

    def handle(self):
        """客户端（演示端/浏览器）断开时不必打印整段 traceback。"""
        try:
            super().handle()
        except (ConnectionResetError, ConnectionAbortedError, BrokenPipeError):
            pass

    def _out(self, body, ctype, code=200):
        self.send_response(code)
        self.send_header("Content-Type", ctype)
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Access-Control-Allow-Origin", "*")
        self.end_headers()
        try:
            self.wfile.write(body)
        except (BrokenPipeError, ConnectionResetError):
            pass

    def _json(self, obj, code=200):
        self._out(json.dumps(obj, ensure_ascii=False).encode(),
                  "application/json; charset=utf-8", code)

    def _serve_asset(self, url_path, prefix="/present/"):
        """把 present/ 下的图片素材发给演示端（logo / banner / 组织 logo）。

        注意 ICPC Tools 既要文件、也要**目录索引**：
        ImageBuildPresentation 先 getDirectory("/presentation/build") 拿列表，
        再用 LinkParser 解析 —— 而 LinkParser 只认 <td><a href="..."> 这种
        Apache 目录索引格式。所以目录要吐一个表格，不能吐 JSON。
        """
        rel = url_path[len(prefix):]
        base = PRESENT_DIR.resolve()
        try:
            f = (base / rel).resolve()
            f.relative_to(base)          # 防目录穿越
        except (ValueError, OSError):
            return self._json({"error": "bad_path", "path": rel}, 400)
        if f.is_dir():
            return self._serve_index(f)
        if not f.is_file():
            print(f"[MISS] asset {rel}", flush=True)
            return self._json({"error": "not_found", "path": rel}, 404)
        ctype = {".png": "image/png", ".jpg": "image/jpeg",
                 ".jpeg": "image/jpeg", ".gif": "image/gif",
                 ".svg": "image/svg+xml"}.get(f.suffix.lower(),
                                              "application/octet-stream")
        return self._out(f.read_bytes(), ctype)

    def _serve_index(self, folder):
        rows = []
        for p in sorted(folder.iterdir()):
            if p.is_file():
                n = p.name
                rows.append(f'<tr><td><a href="{n}">{n}</a></td>'
                            f'<td>{p.stat().st_size}</td></tr>')
        html = ("<!doctype html><html><head><meta charset=\"utf-8\">"
                "<title>Index</title></head><body><table>"
                + "".join(rows) + "</table></body></html>")
        return self._out(html.encode("utf-8"), "text/html; charset=utf-8")

    def do_GET(self):
        p = urllib.parse.urlparse(self.path).path
        if getattr(self, "setup_mode", False):
            return self._get_setup(p)
        cid = self.state.id
        # ---- 配置页面 ----
        if p in ("/config", "/config/"):
            f = WEB_DIR / "config.html"
            if f.exists():
                # 不缓存：页面结构改过之后，浏览器还拿旧版会把新字段覆盖成空
                self.send_response(200)
                self.send_header("Content-Type", "text/html; charset=utf-8")
                body = f.read_bytes()
                self.send_header("Content-Length", str(len(body)))
                self.send_header("Cache-Control", "no-store, must-revalidate")
                self.end_headers()
                try:
                    self.wfile.write(body)
                except (BrokenPipeError, ConnectionResetError):
                    pass
                return
            return self._json({"error": "config.html missing"})

        if p == "/api/config":
            return self._json(self._config_payload())

        # 演示端要的图片素材。ICPC Tools 的 ImageHelper 是去
        #   /presentation/<file>
        # 拿图的（日志里能看到它请求 /presentation/build/），
        # organizations[].logo 的相对路径则按 /api/ 解析。
        # 这几种前缀都接上，省得它对不上。
        for prefix in ("/presentation/", "/api/present/", "/present/",
                       f"/api/contests/{cid}/present/"):
            if p.startswith(prefix):
                return self._serve_asset("/present/" + p[len(prefix):])
        if p == "/api/config/live":
            live = self.store.config_live_snapshot()
            return self._json(live)

        if p in (f"/api/contests/{cid}", "/api/contests/current"):
            return self._json(self.state.meta())
        if p == f"/api/contests/{cid}/teams":
            return self._json(self.store.snapshot("teams"))
        if p == f"/api/contests/{cid}/problems":
            return self._json(self.store.snapshot("problems"))
        if p == f"/api/contests/{cid}/organizations":
            return self._json(self.store.snapshot("organizations"))
        if p == f"/api/contests/{cid}/judgement-types":
            return self._json(JUDGE_TYPES)
        if p == f"/api/contests/{cid}/languages":
            return self._json([{"id": "unknown", "name": "Unknown", "extensions": []}])
        if p == f"/api/contests/{cid}/groups":
            return self._json([{"id": "participants", "name": "参赛队伍"}])
        if p in (f"/api/contests/{cid}/event-feed", "/api/event-feed"):
            q = urllib.parse.parse_qs(urllib.parse.urlparse(self.path).query)
            since = int((q.get("since_id") or ["0"])[0])
            stream = (q.get("stream") or ["true"])[0].lower() != "false"
            if not stream:
                body = "\n".join(self.store.lines(since))
                if body:
                    body += "\n"
                return self._out(body.encode(), "application/x-ndjson; charset=utf-8")
            return self._stream_feed(since)
        if p == "/api/contests":
            return self._json([self.state.meta()])
        if p in ("/api/status", "/api"):
            ev, tm, pb = self.store.counts()
            return self._json({"events": ev, "teams": tm, "problems": pb,
                               "contest": self.state.meta()})
        if p == "/":
            return self._json({"ok": True, "status": "/api/status", "config": "/config",
                               "scorewall": "/scorewall/"})
        # Scorewall 大屏：/scorewall/ 直接伺服移植版前端，数据默认走同源 /api/contests/<id>
        if p == "/scorewall":
            self.send_response(302)
            self.send_header("Location", "/scorewall/")
            self.end_headers()
            return
        if p.startswith("/scorewall/"):
            return self._serve_scorewall(p)
        return self._json({"error": "not_found", "path": p})

    def _serve_scorewall(self, p):
        """把 Scorewall 前端（src/ 下的静态文件）直接发给浏览器。

        index.html 里注入 window.__SRC_DEFAULT__，让前端默认连本适配器，
        不用再手写 ?src=。其余文件按后缀给 MIME，字体也走这里。
        """
        rel = p[len("/scorewall/"):] or "index.html"
        if rel.endswith("/"):
            rel += "index.html"
        base = SCOREWALL_DIR.resolve()
        try:
            f = (base / rel).resolve()
            f.relative_to(base)                  # 防目录穿越
        except (ValueError, OSError):
            return self._json({"error": "bad_path", "path": rel}, 400)
        if not f.is_file():
            print(f"[MISS] scorewall {rel}", flush=True)
            return self._json({"error": "not_found", "path": rel}, 404)

        ctype = {
            ".html": "text/html; charset=utf-8",
            ".js": "text/javascript; charset=utf-8",
            ".mjs": "text/javascript; charset=utf-8",
            ".css": "text/css; charset=utf-8",
            ".json": "application/json; charset=utf-8",
            ".svg": "image/svg+xml",
            ".png": "image/png",
            ".jpg": "image/jpeg",
            ".jpeg": "image/jpeg",
            ".gif": "image/gif",
            ".ttf": "font/ttf",
            ".woff": "font/woff",
            ".woff2": "font/woff2",
        }.get(f.suffix.lower(), "application/octet-stream")

        body = f.read_bytes()
        if f.name == "index.html":
            # 默认数据源指向本进程；显式给了 ?src= 时前端仍以参数优先
            inject = ('<script>window.__SRC_DEFAULT__ = location.origin + '
                      '"/api/contests/" + %r;</script>' % self.state.id)
            body = body.replace(b"<head>", b"<head>\n" + inject.encode("utf-8"), 1)
        # 开发期必须禁缓存：app.js 带 ?v= 会重载，但它 import 的 scoring.js / *-canvas.js
        # 没有版本号，浏览器命中旧缓存就会出现"改了代码但画面不变"的怪现象
        self.send_response(200)
        self.send_header("Content-Type", ctype)
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Cache-Control", "no-store, must-revalidate")
        self.send_header("Access-Control-Allow-Origin", "*")
        self.end_headers()
        try:
            self.wfile.write(body)
        except (BrokenPipeError, ConnectionResetError):
            pass
        return

    def _get_setup(self, p):
        """配置模式：只给配置页和它需要的接口，其它一律 503。"""
        if p in ("/config", "/", "/config.html"):
            return self._serve_config_page()
        if p == "/api/config":
            return self._json(self._config_payload())
        if p == "/api/config/live":
            # 还没连上牛客时也要给前端一个结构完整的空快照，
            # 否则配置页报 live.teams is undefined
            return self._json({
                "contest": {},
                "teams": [],
                "problems": [],
                "statusCounts": {},
                "events": 0,
                "pending": 0,
                "setup_needed": True,
            })
        if p == "/api/status":
            return self._json({"ok": False, "setup": True,
                               "message": "还没有牛客 Cookie，请在配置页填写"})
        if p.startswith("/static/"):
            return self._serve_static(p)
        return self._json({"error": "setup_needed",
                           "message": "还没有牛客 Cookie，先访问 /config"}, code=503)

    def _serve_config_page(self):
        f = WEB_DIR / "config.html"
        if not f.is_file():
            return self._json({"error": "config.html 缺失"}, code=500)
        data = f.read_bytes()
        self.send_response(200)
        self.send_header("Content-Type", "text/html; charset=utf-8")
        self.send_header("Content-Length", str(len(data)))
        self.send_header("Cache-Control", "no-store")
        self.end_headers()
        self.wfile.write(data)

    def _serve_static(self, p):
        f = (WEB_DIR / p[len("/static/"):]).resolve()
        try:
            f.relative_to(WEB_DIR.resolve())
        except ValueError:
            return self._json({"error": "forbidden"}, code=403)
        if not f.is_file():
            return self._json({"error": "not_found"}, code=404)
        data = f.read_bytes()
        self.send_response(200)
        ctype = "image/png" if f.suffix == ".png" else "application/octet-stream"
        self.send_header("Content-Type", ctype)
        self.send_header("Content-Length", str(len(data)))
        self.end_headers()
        self.wfile.write(data)

    def _config_payload(self):
        """配置页要看的全部内容。Cookie 只回显尾巴，不吐完整登录态。"""
        data = dict(self.ov.data) if self.ov else {}
        rt = self.ov.runtime() if self.ov else {}
        ck = ((self.store.nc.cookie if self.store else "") or read_cookie_file())
        return {
            "runtime": rt,
            "cookie": {
                "set": bool(ck),
                "hint": mask_cookie(ck),
                "user": self._cookie_user(ck),
            },
            "contest": data.get("contest") or {},
            "team_defaults": self.ov.team_defaults() if self.ov else {},
            "sites": self.ov.sites() if self.ov else [],
            "teams": data.get("teams") or {},
            "problems": data.get("problems") or {},
            "status_map": data.get("status_map") or {},
        }

    @staticmethod
    def _cookie_user(cookie):
        """从 Cookie 里挑几个能辨认身份的字段回显（不含完整值）。"""
        out = []
        for part in (cookie or "").split(";"):
            k, _, v = part.strip().partition("=")
            if k.strip().lower() in ("nowcoderuid", "userid"):
                out.append(f"{k.strip()}={v.strip()[:6]}…")
        return " ".join(out)

    def do_POST(self):
        p = urllib.parse.urlparse(self.path).path
        if getattr(self, "setup_mode", False) and p != "/api/config":
            return self._json({"error": "setup_needed"}, code=503)
        if p == "/api/config/autodetect":
            if self.store is None:
                return self._json({"ok": False,
                                   "error": "还没连上牛客，先填 Cookie"})
            try:
                learned = self.store.autodetect_status(force=True)
                smap = self.ov.data.get("status_map") if self.ov else {}
                return self._json({"ok": True, "learned": learned, "statusMap": smap})
            except Exception as e:
                return self._json({"error": str(e)})
        if p != "/api/config":
            return self._json({"error": "not_found", "path": p})
        try:
            length = int(self.headers.get("Content-Length") or 0)
            raw = self.rfile.read(length) if length else b"{}"
            body = json.loads(raw.decode("utf-8"))
            if self.ov is None:
                return self._json({"error": "overrides not enabled"})

            old_rt = self.ov.runtime()
            new_rt = dict(old_rt)
            new_rt.update(body.get("runtime") or {})
            # 比赛那一栏允许直接粘链接，这里统一归一化成 ID
            new_rt["contest_id"] = (contest_id_from(new_rt.get("contest_id"))
                                    or old_rt["contest_id"])
            body["runtime"] = new_rt
            self.ov.save(body)

            # Cookie：只有填了才改，空表示保持现状
            raw_cookie = body.get("cookie")
            new_cookie = raw_cookie.strip() if isinstance(raw_cookie, str) else ""
            setup = getattr(self, "setup_mode", False)
            if new_cookie:
                write_cookie_file(new_cookie)
                if self.store is not None:
                    self.store.nc.cookie = new_cookie

            # 配置模式：刚填上 Cookie 就重启进程，让它带着 Cookie 正常起来
            if setup and new_cookie:
                payload = {"ok": True, "restart": True,
                           "config": self._config_payload()}
                self._json(payload)
                self.wfile.flush()
                threading.Timer(1.2, lambda: os._exit(0)).start()
                return None

            if self.store is not None:
                # 比赛级设置（名称/时长/罚时/封榜）
                self.state.refresh()

                switched = None
                if new_rt["contest_id"] != old_rt["contest_id"]:
                    switched = self.store.switch_contest(new_rt["contest_id"])

                # 把已有实体重算一遍（学校/颜色/打星/状态码），变动补发成事件
                self.store.refresh_entities()
            else:
                switched = None
            return self._json({"ok": True, "config": self._config_payload(),
                               "switched": switched})
        except Exception as e:
            return self._json({"error": str(e)})

    def _stream_feed(self, since):
        """长连接 NDJSON 流：先补历史，再持续推送新事件直到客户端断开。

        ICPC Tools 的 RESTContestSource 期待 event-feed 是一条不会主动结束的流，
        关闭连接会被它判定为断开并反复 "Waiting to reconnect"，于是榜单永远为空。
        """
        self.send_response(200)
        self.send_header("Content-Type", "application/x-ndjson; charset=utf-8")
        self.send_header("Cache-Control", "no-cache")
        self.send_header("Connection", "keep-alive")
        self.send_header("Access-Control-Allow-Origin", "*")
        self.end_headers()

        sent = since
        last_beat = time.time()
        try:
            # 先补发已有历史
            for line in self.store.lines(sent):
                self.wfile.write((line + "\n").encode())
                sent += 1
            self.wfile.flush()

            # 之后持续等待新事件（心跳用空行保持连接活跃）
            while True:
                time.sleep(0.5)
                pending = self.store.lines(sent)
                if pending:
                    for line in pending:
                        self.wfile.write((line + "\n").encode())
                    sent += len(pending)
                    self.wfile.flush()
                    last_beat = time.time()
                elif time.time() - last_beat > 15:
                    # 心跳：NDJSON 允许空行，客户端解析器会忽略
                    self.wfile.write(b"\n")
                    self.wfile.flush()
                    last_beat = time.time()
        except (BrokenPipeError, ConnectionResetError, OSError):
            pass    # 客户端主动断开，正常退出


def main():
    ap = argparse.ArgumentParser(
        description="牛客 -> CCS 适配器。比赛/轮询/判题停留等参数都从配置页改，"
                    "命令行只做一次性覆盖。")
    ap.add_argument("--contest", default=None, help="比赛 ID 或比赛链接（缺省读配置）")
    ap.add_argument("--port", type=int, default=None,
                    help="监听端口，缺省读配置（视觉端启动器也按这个连）")
    ap.add_argument("--host", default="127.0.0.1",
                    help="监听地址。127.0.0.1=只本机；0.0.0.0=局域网/云端可访问（注意收敛权限）")
    ap.add_argument("--interval", type=float, default=None, help="轮询间隔（秒，缺省读配置）")
    ap.add_argument("--penalty", type=int, default=None, help="每次错误罚时（秒）")
    ap.add_argument("--name", help="比赛名，缺省用牛客返回的名称")
    ap.add_argument("--fake-pending", type=int, default=None,
                    help="让最早 N 条提交保持未判（演示判题队列用）")
    ap.add_argument("--judge-delay", type=float, default=None,
                    help="提交在判题队列停留多少秒后落到榜单")
    ap.add_argument("--config", default=str(OVERRIDES_PATH),
                    help="配置覆盖文件路径（默认 overrides.json，网页 /config 会写这里）")
    args = ap.parse_args()

    # 配置覆盖层：运行参数/学校/打星/题色/比赛元信息/status 码映射。
    # 网页改一次就落盘，适配器下一轮自动生效，不用重启、不用改代码。
    ov = Overrides(args.config)

    cookie = (os.environ.get("NOWCODER_COOKIE", "").strip()
              or read_cookie_file())
    setup_mode = not cookie

    # 命令行显式给的运行参数落回配置，保证网页上看到的就是正在跑的
    rt = ov.runtime()
    override = {}
    if args.contest:
        override["contest_id"] = contest_id_from(args.contest)
    if args.interval is not None:
        override["poll_interval"] = args.interval
    if args.judge_delay is not None:
        override["judge_delay"] = args.judge_delay
    if args.fake_pending is not None:
        override["fake_pending"] = args.fake_pending
    if args.port is not None:
        override["port"] = args.port
    if override:
        rt.update(override)
        ov.data["runtime"] = rt
        ov.save(ov.data)
    rt = ov.runtime()
    port = rt["port"]

    if args.penalty is not None:
        ov.data.setdefault("contest", {})["penalty_sec"] = args.penalty
    if args.name:
        ov.data.setdefault("contest", {})["name"] = args.name
    if args.penalty is not None or args.name:
        ov.save(ov.data)

    # ---- 没 Cookie：先把配置页跑起来，填完自动重启进正常模式 ----
    if setup_mode:
        Handler.ov = ov
        Handler.store = None
        Handler.state = None
        Handler.setup_mode = True
        srv = ThreadingHTTPServer((args.host, port), Handler)
        shown = "127.0.0.1" if args.host in ("0.0.0.0", "::") else args.host
        print()
        print("!! 还没有牛客 Cookie，进“配置模式”：只提供配置页")
        print(f"   打开 http://{shown}:{port}/config 填 Cookie，保存后会自动重启")
        print()
        try:
            srv.serve_forever()
        except KeyboardInterrupt:
            print("bye")
        return

    nc = Nowcoder(rt["contest_id"], cookie, ov=ov)

    print("首次拉取牛客数据...")
    probs, records, nc_ok = [], [], False
    for attempt in range(1, 6):
        try:
            probs, records = nc.poll()
            nc_ok = True
            break
        except Exception as e:
            print(f"  第 {attempt} 次拉取失败: {e}", file=sys.stderr)
            if attempt < 5:
                time.sleep(3)

    if not nc_ok:
        # 网络抖动 / SSL 断连时不能把整个服务停掉：
        # 用配置里的时间先起服务（数据为空），后台轮询线程会继续重试。
        cfg_c = ov.contest() or {}
        dm = int(cfg_c.get("duration_min") or 300)
        start = datetime.now(TZ)
        end = start + timedelta(minutes=dm)
        name = cfg_c.get("name") or f"牛客 {rt['contest_id']}"
        state = ContestState(rt["contest_id"], name, start, end, 1200, ov=ov)
        store = FeedStore(state, nc, fake_pending=rt["fake_pending"],
                          judge_delay=rt["judge_delay"], ov=ov)
        Handler.store = store
        Handler.state = state
        Handler.ov = ov
        print("!! 连不上牛客（网络或 Cookie），已用配置里的时间先起服务，后台继续重试")
        print(f"   {state.name}  时长 {dm} 分钟")
    else:
        pass

    learned = {}
    if nc_ok:
      # 没见过的 status 码：去提交详情页读真实判题结论，别再靠数字猜。
      try:
          learned = nc.autodetect_verdicts(records)
      except Exception as e:
          learned = {}
          print(f"  状态码识别失败（不影响启动）: {e}")
      if learned:
          print("  自动识别状态码: "
                + ", ".join(f"{k}={v}" for k, v in learned.items()))
          nc.remap(records)

    added = 0
    if nc_ok:
        c = nc.contest
        start_ms = c.get("startTime")
        end_ms = c.get("endTime")
        if not start_ms or not end_ms:
            print("错误：牛客未返回 startTime/endTime", file=sys.stderr)
            sys.exit(3)

        start = datetime.fromtimestamp(start_ms / 1000, TZ)
        end = datetime.fromtimestamp(end_ms / 1000, TZ)
        name = args.name or c.get("name") or f"牛客 {rt['contest_id']}"

        base_penalty = int((ov.contest() or {}).get("penalty_sec") or 1200)
        state = ContestState(rt["contest_id"], name, start, end, base_penalty, ov=ov)
        store = FeedStore(state, nc, fake_pending=rt["fake_pending"],
                          judge_delay=rt["judge_delay"], ov=ov)
        added = store.ingest(records, probs)

        Handler.store = store
        Handler.state = state
        Handler.ov = ov

    print(f"  比赛    : {state.name}")
    print(f"  开始    : {start:%Y-%m-%d %H:%M:%S}")
    print(f"  结束    : {end:%Y-%m-%d %H:%M:%S}  (时长 {state.duration_min} 分钟)")

    if state.duration_min_override:

        print(f"  注意    : 牛客 endTime 算出 {int((end-start).total_seconds()//60)} 分钟，超出常规，已截断为 {state.duration_min} 分钟")
    print(f"  题目    : {len(probs)} 道")
    print(f"  提交    : {len(records)} 条 -> 事件 {added} 条")
    print(f"  轮询    : 每 {rt['poll_interval']:.1f} 秒（配置页可改）")
    print(f"  判题停留: {rt['judge_delay']:.1f} 秒后从判题队列落到榜单")
    if rt["fake_pending"] > 0:
        print(f"  开场铺垫: 最早 {rt['fake_pending']} 条永久留作 pending")
    print(f"  配置文件: {ov.path}")

    def poller():
        while True:
            # 轮询间隔每轮现读，配置页改完不用重启
            time.sleep(ov.runtime()["poll_interval"])
            try:
                pr, rec = nc.poll()
                n = store.ingest(rec, pr)
                # 把到期的延迟 judgement 落盘
                n += store.tick()

                # 出现没见过的 status 码：自动去详情页读真实结论并记进配置。
                # 这样比赛里真有人 TLE/MLE 了，不用人工干预也能抓到码值。
                known_map = ov.data.get("status_map") or {}
                unknown = {str(r.get("status")) for r in rec
                           if str(r.get("status")) not in known_map}
                if unknown:
                    fresh = {c for c in unknown if c not in store._probed_codes}
                    learned = store.autodetect_status()
                    if learned:
                        print(f"[{datetime.now(TZ):%H:%M:%S}] 自动识别状态码: "
                              + ", ".join(f"{k}={v}" for k, v in learned.items()),
                              flush=True)
                        n += 1
                    elif fresh:
                        print(f"[{datetime.now(TZ):%H:%M:%S}] 发现新状态码 {sorted(fresh)}，"
                              f"详情页没给出可映射的结论（可在配置页手动指定）", flush=True)

                if n:
                    ev, tm, pb = store.counts()
                    pend = store.pending_count()
                    msg = (f"[{datetime.now(TZ):%H:%M:%S}] +{n} 事件 "
                           f"(总 {ev}) 队伍 {tm} 题目 {pb}")
                    if pend:
                        msg += f" 待判 {pend}"
                    print(msg, flush=True)
            except Exception as e:
                print(f"[{datetime.now(TZ):%H:%M:%S}] 轮询错误: {e}", flush=True)

    threading.Thread(target=poller, daemon=True).start()

    srv = ThreadingHTTPServer((args.host, port), Handler)
    print()
    shown = "127.0.0.1" if args.host in ("0.0.0.0", "::") else args.host
    print(f"CCS 适配器: http://{shown}:{port}")
    print(f"配置页面  : http://{shown}:{port}/config")
    print(f"视觉端    : python visual.py   （或 visual.bat 双击）")
    print(f"ICPC Tools: standalone http://{shown}:{port}/api/contests/{state.id} admin x -p 56")
    print()
    try:
        srv.serve_forever()
    except KeyboardInterrupt:
        print("bye")


if __name__ == "__main__":
    sys.stdout.reconfigure(encoding="utf-8")
    main()
